#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(int argc, char* argv[]){
	
	if(argc != 2){
		printf("Only one argument must be passed!\n");
		return 0;
	}
	
	int size = atoi(argv[1]);
	if(size < 0){
		printf("Invalid Size!\n");
		return 0;
	}
	
	for(int i = 0; i < size; i++){
		pid_t pid = fork();
		if(pid < 0){
			perror("Fork Failed!\n");
			exit(1);
		}
		
		if(pid == 0){
			printf("Child %d's PID: %d, Parent's PID: %d\n", i+1, getpid(), getppid());
			return 0;
		}
		else if(i == size-1){
			wait(NULL);
			printf("Original Parent's PID: %d\n", getpid());
			printf("Total Children: %d\n", i+1);
		}
	}
	return 0;
}
