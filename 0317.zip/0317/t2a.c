#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(){
	
	pid_t pid = fork();
	
	if(pid < 0){
		perror("Fork Failed!\n");
		exit(1);
	}
	
	if(pid == 0){
		printf("Child 1's PID: %d, Parent's PID: %d\n", getpid(), getppid());
	}
	else{
		printf("Original Parent's PID: %d\n", getpid());
		pid_t Pid = fork();
		if(Pid == 0){
		printf("Child 2's PID: %d, Parent's PID: %d\n", getpid(), getppid());
		}
		else{
			pid_t PId = fork();	
			if(PId == 0){
				printf("Child 3's PID: %d, Parent's PID: %d\n", getpid(), getppid());
			}
		}
	}
	
	return 0;
}
