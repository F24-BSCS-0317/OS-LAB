#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int arr[] = {1,2,3,4,5};
int main(){
	
	pid_t pid = fork();
	
	if(pid < 0){
		perror("Fork Failed!\n");
		exit(1);
	}
	
	if(pid == 0){
		for(int i = 0; i < 5; i++){
			arr[i] = arr[i]*arr[i];
		}
		for(int i = 0; i < 5; i++){
			printf("%d ", arr[i]);
		}
		printf("\nChild's PID: %d, Parent's PID = %d\n", getpid(), getppid());
		exit(0);
	}
	else{
		wait(NULL);
		for(int i = 0; i < 5; i++){
			printf("%d ", arr[i]);
		}		
		printf("\nChild's PID: %d, Parent's PID = %d\n", pid, getpid());
	}
	
	return 0;
}
