#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int checkPrime(int num){
	for(int i = 1; i < num; i++){
		for(int j = 1; j < num; j++){
			if(i*j == num){
				return 0;
			}
		}
	}
	return 1;
}

int Sum(int num){
	int sum = 0;
	for(int i = 0; i <= num; i++){
		sum += i;
	}
	return sum;
}

int main(int argc, char* argv[]){
	
	if(argc != 2){
		printf("Only one argument must be passed!\n");
		return 0;
	}
	
	int num = atoi(argv[1]);
	
	for(int i = 0; i < 3; i++){
		pid_t pid = fork();
		if(pid < 0){
			perror("Fork Failed!\n");
			exit(1);
		}
		if(pid == 0){
			if(i == 0){
				int flag = checkPrime(num);
				if(flag){
					printf("Prime!\n");
				}
				else{
					printf("Not Prime!\n");					
				}
				exit(flag);
			}
			else if(i == 1){
				int sum = Sum(num);	
				printf("Sum = %d\n", sum);
				exit(sum);
			}
			else{
				perror("Failing Child 3");
				exit(1);
			}
			return 0;
		}
		else{
			int status;
			waitpid(pid, &status, 0);
			printf("Original Parent's PID: %d\nStatus: %d\n", getpid(), status);
			
		}
	}
	return 0;
}
