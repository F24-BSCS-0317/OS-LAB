#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(){
	pid_t pid = fork();
	if(pid < 0){
		perror("Fork Failed!\n");
		exit(1);
	}
	if(pid == 0){
		pid_t Pid = fork();
		if(Pid < 0){
			perror("Fork Failed!\n");
			exit(1);
		}
		if(Pid == 0){
			printf("Child G1's PID: %d, Parent's PID: %d\n", getpid(), getppid());
		}
		else{
			wait(NULL);
			printf("Child C1's PID: %d, Parent's PID: %d\n", getpid(), getppid());
			exit(0);
		}
	}
	else{
		pid_t Pid = fork();
		if(Pid < 0){
			perror("Fork Failed!\n");
			exit(1);
		}
		if(Pid == 0){
			printf("Child C2's PID: %d, Parent's PID: %d\n", getpid(), getppid());
		}
		else{
			wait(NULL);
			wait(0);
			printf("Original Parent's PID: %d\n", getpid());
		}
	}
	
	return 0;
}
