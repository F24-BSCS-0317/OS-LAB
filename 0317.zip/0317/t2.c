#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/wait.h>

int main(){
	
	fork();
	fork();
	fork();
	printf("Child's PID: %d, Parent's PID = %d\n", getpid(), getppid());
	
	return 0;
}
